﻿//using Microsoft.AspNetCore.Mvc;
////using WebApplication1.models

//using WebApplication1.Models;

////using WebApplication1.Models;
//namespace WebApplication1
//{
//    public class ProductCatagoryController : Controller
//    {

//        public IActionResult Index()
//        {

//            ProductRepository pr = new ProductRepository();
//            List<productCat> product = pr.ViewAll();
//            return View(product);
//        }

//    }
//}
