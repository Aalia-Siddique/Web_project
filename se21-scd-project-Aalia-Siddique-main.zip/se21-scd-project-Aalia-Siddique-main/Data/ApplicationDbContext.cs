﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using WebApplication1.Models;

namespace WebApplication1.Data
{
	public class ApplicationDbContext : IdentityDbContext<MyUser>
	{

		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
			: base(options)
		{
			try
			{
				var databaseCreater = Database.GetService<IDatabaseCreator>() as RelationalDatabaseCreator;
				if (databaseCreater != null)
				{
					if (!databaseCreater.CanConnect())
					{
						databaseCreater.Create();
					}
					if (!databaseCreater.HasTables())
					{
						databaseCreater.CreateTables();
					}
				}

			}
			catch (Exception ex) 
			{
				Console.WriteLine(ex.Message);
			}

		}
		public DbSet<Product> Products { get; set; }
        public DbSet<Catagory> Catagorys{ get; set; }
        public DbSet<Feedback> Feedbacks{ get; set; }
    }
}
