﻿using WebApplication1.Models;
namespace WebApplication1.Models
{
    public interface IRepository<TEntity> where TEntity : class
    {
        public void Add(TEntity entity);
        public void Delete(string id);
        public void Update(TEntity entity);
        public IEnumerable<TEntity> GetAll();
        public TEntity FindById(string id);
        public TEntity FindByName(string name);
        public IEnumerable<Product1> GetTopSearchedProducts();
        public void IncrementSearchCount(int productId);
        public IEnumerable<TEntity> FindByCategoryId(string categoryId);

        //  public TEntity FindById(int id);
    }
}
