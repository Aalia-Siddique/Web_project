﻿namespace WebApplication1.Models
{

    public class CartViewModel
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public string ProductName { get; set; }
        public string ProductPrice { get; set; }
        public string ProductImagePath { get; set; }
        public string TotalPrice { get; set; }
    }
}