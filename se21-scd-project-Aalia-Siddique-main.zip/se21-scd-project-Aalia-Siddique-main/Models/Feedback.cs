﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Feedback
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Satisfaction rating is required")]
        [Range(1, 5, ErrorMessage = "Satisfaction rating must be between 1 and 5")]
        public int Satisfaction { get; set; }

        [Required(ErrorMessage = "Suggestions are required")]
        [MinLength(50, ErrorMessage = "Suggestions must be at least 50 characters long")]
        public string Suggestions { get; set; }
    }
}
