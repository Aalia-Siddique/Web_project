﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Product
    {
        [Required]
        public int ProductId { get; set; }

        [Required]

        [NotAllowedWordsAttribute1(new string[] { "breakfast", "lunch" })]

        public string category { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        //[DataType(DataType.Currency)]
        public string Price { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public string Quantity { get; set; }

        
       [Required]
        public string ImagePath { get; set; }
    }
}
