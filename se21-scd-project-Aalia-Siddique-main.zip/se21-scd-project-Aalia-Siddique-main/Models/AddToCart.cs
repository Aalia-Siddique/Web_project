﻿namespace WebApplication1.Models
{
    public class AddToCart
    {
            public int Id { get; set; }
        // Primary Key
        public string Name { get; set; }

        public string UserId { get; set; }  // Foreign Key to the User

          
            public string ProductId { get; set; }
        // Foreign Key to the Product

        public string Price { get; set; }
        public string ImagePath { get; set; }

        public int Quantity { get; set; }  // Quantity of the product in the cart

           
            public DateTime AddedDate { get; set; }  // Date when the product was added to the cart

           
           
            public virtual Product Product { get; set; }

       
     
        public decimal PriceDecimal => decimal.Parse(Price.Replace("$", ""));
        public decimal TotalPrice => Quantity * PriceDecimal;
    }
}
   

