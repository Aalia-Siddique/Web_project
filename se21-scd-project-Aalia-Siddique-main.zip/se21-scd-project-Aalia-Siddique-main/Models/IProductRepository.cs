﻿using WebApplication1.Models;
public interface IProductRepository
{
    void Add(Product p);
    void Update(Product product);
    void DeleteById(string id);
    void DeleteByName(string name);
    Product Get();
    List<Product> GetAll();
    void CopyProductData();
    List<productCat> ViewAll();
    int GetTotalProductsCount();
    int GetTotalOrdersCount();
}
