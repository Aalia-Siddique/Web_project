﻿using System;
using System.Collections.Generic;
using WebApplication1.Models;
namespace WebApplication1.Models
{
    public interface IFeedbackRepository
    {
        void Update(int id, string description);
        // You can add other methods for feedback operations if needed
    }
}
