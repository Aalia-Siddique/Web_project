﻿using System.Runtime.InteropServices;
using Microsoft.AspNetCore.Identity;
using WebApplication1.Models;
namespace WebApplication1.Models
{
    public class MyUser:IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Role { get; set; }




    }
}
