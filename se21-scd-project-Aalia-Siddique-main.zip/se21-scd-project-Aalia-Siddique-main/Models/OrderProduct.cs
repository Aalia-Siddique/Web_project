﻿//namespace WebApplication1.Models
//{
//    public class OrderProduct
//    {
//        public Order Customer { get; set; }
//        public List<Product> Products { get; set;}
//    }
//}
