﻿//using Microsoft.Data.SqlClient;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Data.SqlClient;
//using Microsoft.Data.SqlClient;
//using System.Text.Json;
//using System.Text.Json.Serialization;
//using System.Collections.Generic;

//namespace WebApplication1.Models
//{
//    public class OrderRepository
//    {
        
//        public  void AddProd(Orders o)
//        {
//            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyDB;Integrated Security=True";
//            string insertQuery = @"
//            INSERT INTO [dbo].[Order] (Name, Email, Cnic, Address, Quantity, ProductName)
//            VALUES (@Name, @Email, @Cnic, @Address, @Quantity, @ProductName);";

//            using (SqlConnection connection = new SqlConnection(connectionString))
//            {
//                SqlCommand command = new SqlCommand(insertQuery, connection);

//                // Add parameters
//                command.Parameters.AddWithValue("@Name", o.Name);
//                command.Parameters.AddWithValue("@Email", o.Email);
//                command.Parameters.AddWithValue("@Cnic", o.Cnic);
//                command.Parameters.AddWithValue("@Address",o.Address);
//                command.Parameters.AddWithValue("@Quantity", o.Quantity);
//                command.Parameters.AddWithValue("@ProductName",o.ProductName);

//                try
//                {
//                    connection.Open();
//                    int rowsAffected = command.ExecuteNonQuery();
//                    Console.WriteLine($"Rows affected: {rowsAffected}");
//                    Console.WriteLine("Data inserted successfully.");
//                }
//                catch (Exception ex)
//                {
//                    Console.WriteLine("Error inserting data: " + ex.Message);
//                }
//            }
//        }
//    }
//}
