﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using WebApplication1.Models;

namespace WebApplication1.Models
{
    public class GenericRepository<TEntity> : IRepository<TEntity> where TEntity : class, new()
    {
        private readonly string _connstring;
      //  private readonly ILogger<GenericRepository<TEntity>> _logger;

        public GenericRepository(IConfiguration configuration)
        {
            _connstring = configuration.GetConnectionString("DefaultConnection");
            
        }

        public void Add(TEntity entity)
        {
            var tableName = typeof(TEntity).Name;
            var properties = typeof(TEntity).GetProperties().Where(p => p.Name != "Id");
            var columnNames = string.Join(",", properties.Select(x => x.Name));
            var parameters = string.Join(",", properties.Select(y => "@" + y.Name));
            var query = $"INSERT INTO [{tableName}] ({columnNames}) VALUES ({parameters})";

            using (var connection = new SqlConnection(_connstring))
            {
                try
                {
                    connection.Open();
                    connection.Execute(query, entity);
                  
                }
                catch (Exception ex)
                {
                   // _logger.LogError(ex, "An error occurred while adding an entity to {TableName}", tableName);
                    Debug.WriteLine($"Error adding entity to {tableName}: {ex.Message}");
                    Trace.WriteLine($"Error adding entity to {tableName}: {ex}");
                    throw;
                }
            }
        }

        public void Update(TEntity entity)
        {
            var tableName = typeof(TEntity).Name;
            var primaryKey = "Id"; // Adjust this based on your primary key naming convention
            var properties = typeof(TEntity).GetProperties().Where(x => x.Name != primaryKey);
            var setClause = string.Join(",", properties.Select(a => $"{a.Name}=@{a.Name}"));
            var query = $"UPDATE [{tableName}] SET {setClause} WHERE {primaryKey} = @{primaryKey}";

            using (var connection = new SqlConnection(_connstring))
            {
                try
                {
                    connection.Open();
                    connection.Execute(query, entity);
                   // _logger.LogInformation("Entity updated in {TableName}", tableName);
                }
                catch (Exception ex)
                {
                 //   _logger.LogError(ex, "An error occurred while updating an entity in {TableName}", tableName);
                    Debug.WriteLine($"Error updating entity in {tableName}: {ex.Message}");
                    Trace.WriteLine($"Error updating entity in {tableName}: {ex}");
                    throw;
                }
            }
        }

        public void Delete(string id)
        {
            var tableName = typeof(TEntity).Name;
            var query = $"DELETE FROM [{tableName}] WHERE Id=@Id";

            using (var connection = new SqlConnection(_connstring))
            {
                try
                {
                    connection.Open();
                    connection.Execute(query, new { Id = id });
                 //   _logger.LogInformation("Entity with ID {Id} deleted from {TableName}", id, tableName);
                }
                catch (Exception ex)
                {
                 //   _logger.LogError(ex, "An error occurred while deleting an entity from {TableName}", tableName);
                    Debug.WriteLine($"Error deleting entity from {tableName}: {ex.Message}");
                    Trace.WriteLine($"Error deleting entity from {tableName}: {ex}");
                    throw;
                }
            }
        }

        public IEnumerable<TEntity> GetAll()
        {
            var tableName = typeof(TEntity).Name;
            var query = $"SELECT * FROM [{tableName}]";

            using (var connection = new SqlConnection(_connstring))
            {
                try
                {
                    connection.Open();
                    return connection.Query<TEntity>(query).ToList();
                }
                catch (Exception ex)
                {
                    //_logger.LogError(ex, "An error occurred while retrieving all entities from {TableName}", tableName);
                    Debug.WriteLine($"Error retrieving entities from {tableName}: {ex.Message}");
                    Trace.WriteLine($"Error retrieving entities from {tableName}: {ex}");
                    throw;
                }
            }
        }

        public TEntity FindById(string id)
        {
            var tableName = typeof(TEntity).Name;
            var query = $"SELECT * FROM [{tableName}] WHERE Id = @Id";

            using (var connection = new SqlConnection(_connstring))
            {
                try
                {
                    connection.Open();
                    return connection.QuerySingleOrDefault<TEntity>(query, new { Id = id });
                }
                catch (Exception ex)
                {
                   // _logger.LogError(ex, "An error occurred while finding an entity by ID in {TableName}", tableName);
                    Debug.WriteLine($"Error finding entity by ID in {tableName}: {ex.Message}");
                    Trace.WriteLine($"Error finding entity by ID in {tableName}: {ex}");
                    throw;
                }
            }
        }

        public TEntity FindByName(string name)
        {
            var tableName = typeof(TEntity).Name;
            var query = $"SELECT * FROM [{tableName}] WHERE Name = @Name";

            using (var connection = new SqlConnection(_connstring))
            {
                try
                {
                    connection.Open();
                    return connection.QuerySingleOrDefault<TEntity>(query, new { Name = name });
                }
                catch (Exception ex)
                {
                  //  _logger.LogError(ex, "An error occurred while finding an entity by name in {TableName}", tableName);
                    Debug.WriteLine($"Error finding entity by name in {tableName}: {ex.Message}");
                    Trace.WriteLine($"Error finding entity by name in {tableName}: {ex}");
                    throw;
                }
            }
        }

        public void IncrementSearchCount(int productId)
        {
            using (var connection = new SqlConnection(_connstring))
            {
                try
                {
                    connection.Open();
                    var checkQuery = "SELECT COUNT(*) FROM [dbo].[Product1] WHERE [Id] = @ProductId";
                    var count = connection.ExecuteScalar<int>(checkQuery, new { ProductId = productId });

                    if (count > 0)
                    {
                        var incrementQuery = "UPDATE [dbo].[Product1] SET [SearchCount] = [SearchCount] + 1 WHERE [Id] = @ProductId";
                        connection.Execute(incrementQuery, new { ProductId = productId });
                       // _logger.LogInformation("Search count incremented for ProductId {ProductId}", productId);
                    }
                    else
                    {
                       // _logger.LogWarning("Product with ProductId {ProductId} not found", productId);
                    }
                }
                catch (Exception ex)
                {
                    //_logger.LogError(ex, "An error occurred while incrementing search count for ProductId {ProductId}", productId);
                    Debug.WriteLine($"Error incrementing search count for ProductId {productId}: {ex.Message}");
                    Trace.WriteLine($"Error incrementing search count for ProductId {productId}: {ex}");
                    throw;
                }
            }
        }

        public IEnumerable<Product1> GetTopSearchedProducts()
        {
            var query = "SELECT TOP 5 [Id], [Name], [Price], [Description], [ImagePath], [SearchCount] " +
                        "FROM [dbo].[Product1] ORDER BY [SearchCount] DESC";

            using (var connection = new SqlConnection(_connstring))
            {
                try
                {
                    connection.Open();
                    return connection.Query<Product1>(query).ToList();
                }
                catch (Exception ex)
                {
                   // _logger.LogError(ex, "An error occurred while retrieving top searched products");
                    Debug.WriteLine($"Error retrieving top searched products: {ex.Message}");
                    Trace.WriteLine($"Error retrieving top searched products: {ex}");
                    throw;
                }
            }
        }

        public IEnumerable<TEntity> FindByCategoryId(string categoryId)
        {
            var tableName = typeof(TEntity).Name;
            var query = $"SELECT * FROM [{tableName}] WHERE Id = @CategoryId";

            using (var connection = new SqlConnection(_connstring))
            {
                try
                {
                    connection.Open();
                    return connection.Query<TEntity>(query, new { CategoryId = categoryId }).ToList();
                }
                catch (Exception ex)
                {
                //    _logger.LogError(ex, "An error occurred while finding entities by category ID in {TableName}", tableName);
                    Debug.WriteLine($"Error finding entities by category ID in {tableName}: {ex.Message}");
                    Trace.WriteLine($"Error finding entities by category ID in {tableName}: {ex}");
                    throw;
                }
            }
        }
    }
}
