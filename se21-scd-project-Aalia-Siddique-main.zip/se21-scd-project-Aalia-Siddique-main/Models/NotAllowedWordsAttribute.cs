﻿//using System;
//using System.ComponentModel.DataAnnotations;
//namespace WebApplication1.Models
//{
//    public class NotAllowedWordsAttribute : ValidationAttribute
//    {
//        private readonly string[] _AllowedWords = { "small", "medium", "large" };

//        protected override NotAllowedWordsAttribute IsValid(object? value, 
//            ValidationContext validationContext)
//        {
//            if (value == null || value is not string size)
//            {
//                return new ValidationResult("Invalid input.");
//            }

//            if (Array.Exists(_AllowedWords, word => word.Equals(size, StringComparison.OrdinalIgnoreCase)))
//            {
//                return ValidationResult.Success;
//            }
//            else
//            {
//                return new ValidationResult("The size must be 'small', 'medium', or 'large'.");
//            }
//        }

//    }

//}


using System.ComponentModel.DataAnnotations;

namespace  WebApplication1.Models
{
    public class NotAllowedWordsAttribute : ValidationAttribute
    {
        private readonly string[] _AllowedWords ={ "lunch", "medium", "large" };

        //public NotAllowedWordsAttribute(string[] notAllowedWords)
        //{
        //    _AllowedWords = notAllowedWords;
        //}

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null || value is not string size)
            {
                return new ValidationResult("Invalid input.");
            }
            if (Array.Exists(_AllowedWords, word => word.Equals(size, StringComparison.OrdinalIgnoreCase)))
            {
                return ValidationResult.Success;
            }
            else
            {
                return new ValidationResult("The size must be 'small', 'medium', or 'large'.");
            }
        }

    }
}

