﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using WebApplication1.Models;


namespace WebApplication1.Models
{
    public class FeedbackRepo : IFeedbackRepository
    {
        private readonly string _connectionString;

        public FeedbackRepo()
        {
            _connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyDB;Integrated Security=True";
        }

        public void Update(int id, string description)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "UPDATE [dbo].[Feedback] SET [Description] = @Description WHERE [Id] = @Id";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Description", description);
                command.Parameters.AddWithValue("@Id", id);

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();
            }
        }
    }
}
