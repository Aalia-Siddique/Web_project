﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Catagory
    {
        [Required]
        public int Id { set; get; }
        [Required]
        [NotAllowedWordsAttribute1(new string[] { "badword", "spam" })]
        public string catagoryName { set; get; }

    }
}
