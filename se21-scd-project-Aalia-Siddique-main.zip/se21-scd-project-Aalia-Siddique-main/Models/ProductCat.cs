﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class productCat
    {
        public Catagory cat { get; set; }
        public List<Product> PList { get; set; }
       
    }
}