﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.SqlClient;
using Dapper;
using WebApplication1.Models;
namespace WebApplication1.Models
{
    public class ProductRepository : IRepository<Product>
    {
        private readonly string _connectionString = "Data Source=webapplication1DB;initial Catalog=student1DB;User ID=sa;Password=aaliaSidd123#;TrustServerCertificate=True;";
        private readonly IRepository<Product> _repository;
        public ProductRepository(IRepository<Product> repository)
        {
            _repository = repository;
        }
        public void Add(Product p)
        {
            using (var con = new SqlConnection(_connectionString))
            {
                con.Open();
                var categoryId = con.ExecuteScalar<int>("SELECT Id FROM dbo.Catagory WHERE catagoryName = @catName", new { catName = p.category });

                var insertQuery = "INSERT INTO dbo.Product (Name, Price, Description, Quantity, ImagePath, Id) VALUES (@Name, @Price, @Description, @Quantity, @ImagePath, @CategoryId)";
                con.Execute(insertQuery, new { p.Name, p.Price, p.Description, p.Quantity, p.ImagePath, CategoryId = categoryId });
            }
        }
        public void Delete(string id)
        {
            _repository.Delete(id); 
        }
        public void Update(Product product)
        {
           //repository.Update(product);
        
            using (var con = new SqlConnection(_connectionString))
            {
                var query = "UPDATE [dbo].[Product] SET [Name] = @Name, [Price] = @Price, [Description] = @Description, [Quantity] = @Quantity, [ImagePath] = @ImagePath WHERE [ProductId] = @ProductId";
    con.Execute(query, product);
            }
        }
        public void DeleteById(string id)
        {
            using (var con = new SqlConnection(_connectionString))
            {
                // Open the connection
                con.Open();

                // Start a transaction
                using (var transaction = con.BeginTransaction())
                {
                    try
                    {
                        // Check if there are any dependent rows in the OrderItems table
                        var dependentOrderItems = con.Query<int>(
                            "SELECT COUNT(*) FROM [dbo].[OrderItems] WHERE ProductId = @ProductId",
                            new { ProductId = id },
                            transaction: transaction
                        ).Single();

                        // If there are dependent rows, delete them first
                        if (dependentOrderItems > 0)
                        {
                            var deleteOrderItemsQuery = "DELETE FROM " +
                                "[dbo].[OrderItems] WHERE ProductId = @ProductId";
                            con.Execute(deleteOrderItemsQuery, new { ProductId = id }, transaction: transaction);
                        }

                        // Now delete the product
                        var deleteProductQuery = "DELETE FROM [dbo].[Product] " +
                            "WHERE ProductId = @ProductId";
                        con.Execute(deleteProductQuery, new { ProductId = id }, transaction: transaction);

                        // Commit the transaction
                        transaction.Commit();
                    }
                    catch (Exception)
                    {
                        // Rollback the transaction if something went wrong
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        //public void DeleteById(string id)
        //{
        //    using (var con = new SqlConnection(_connectionString))
        //    {
        //        var query = "DELETE FROM [dbo].[Product] WHERE ProductID = @ProductId";
        //        con.Execute(query, new { ProductId = id });
        //    }
        //}

        public void DeleteByName(string name)
        {
            using (var con = new SqlConnection(_connectionString))
            {
                var query = "DELETE FROM Product WHERE Name = @Name";
                con.Execute(query, new { Name = name });
            }
        }

        public Product Get()
        {
            using (var con = new SqlConnection(_connectionString))
            {
                return con.QuerySingleOrDefault<Product>("SELECT TOP 1 * FROM dbo.Product");
            }
        }
        public IEnumerable<Product> GetAll()
        {
            return _repository.GetAll();
        }
        //public List<Product> GetAll()
        //{
        //    using (var con = new SqlConnection(_connectionString))
        //    {
        //        return con.Query<Product>("SELECT * FROM dbo.Product").ToList();
        //    }
        //}

        public void CopyProductData()
        {
            using (var con = new SqlConnection(_connectionString))
            {
                var copyDataQuery = "INSERT INTO [dbo].[Product1] (Name, Price, Description, Quantity, ImagePath, CatagoryId) SELECT Name, Price, Description, Quantity, ImagePath, Id FROM [dbo].[Product]";
                con.Execute(copyDataQuery);
            }
        }

        public List<productCat> ViewAll()
        {
            string con = "Data Source=(localdb)\\MSSQLLocalDB;" +
                "Initial Catalog=MyDB;Integrated Security=True";


            List<productCat> productCatList = new List<productCat>();

            using (SqlConnection conn = new SqlConnection(con))
            {
                conn.Open();
                string query = @"
            SELECT p.ProductId,p.Id, p.Name, p.Price,p.Description, p.ImagePath,
          s.catagoryName 
            FROM Product p
            INNER JOIN Catagory s ON p.Id = s.Id";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    int categoryId = (int)reader["Id"];
                    var category = productCatList.FirstOrDefault
                    (pc => pc.cat.Id == categoryId);
                    if (category == null)
                    {
                        category = new productCat
                        {
                            cat = new Catagory
                            {
                                Id = categoryId,
                                catagoryName = reader["catagoryName"].ToString()
                            },
                            //   SubcategoryName = reader["SubcategoryName"].ToString(),
                            PList = new List<Product>()
                        };
                        productCatList.Add(category);
                    }

                    category.PList.Add(new Product
                    {
                        ProductId = (int)reader["ProductId"],
                        Name = reader["Name"].ToString(),
                        Price = reader["Price"].ToString(),
                        Description = reader["Description"].ToString(),
                        //  items = (int)reader["items"],
                        ImagePath = reader["ImagePath"].ToString(),
                        // CategoryID = (int)reader["SubcategoryId"]
                    });
                }
            }
            return productCatList;
        }

        public int GetTotalProductsCount()
        {
            using (var con = new SqlConnection(_connectionString))
            {
                return con.ExecuteScalar<int>("SELECT COUNT(*) FROM dbo.Product");
            }
        }

        public int GetTotalOrdersCount()
        {
            using (var con = new SqlConnection(_connectionString))
            {
                return con.ExecuteScalar<int>("SELECT COUNT(*) FROM dbo.Orders");
            }
        }
        public Product FindById(string id)
        {
            return _repository.FindById(id);
        }
        public Product FindByName(string name)
        {
            return _repository.FindByName(name);
        }
        public IEnumerable<Product1> GetTopSearchedProducts()
        {
            return _repository.GetTopSearchedProducts();
        }
        public void IncrementSearchCount(int productId)
        {
            _repository.IncrementSearchCount(productId);
        }
        public IEnumerable<Product> FindByCategoryId(string categoryId)
        {
            return _repository.FindByCategoryId( categoryId);
        }
    }
}

   