﻿namespace Application
{
	public class Class1
	{

	}
}
