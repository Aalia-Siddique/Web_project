using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using WebApplication1.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using WebApplication1.Models;

var builder = WebApplication.CreateBuilder(args);
// Add services to the container.
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

builder.Services.AddScoped(typeof(IRepository<>), typeof(GenericRepository<>));

builder.Services.AddScoped<IFeedbackRepository, FeedbackRepo>();
builder.Services.AddScoped< ProductRepository>();



builder.Services.AddDefaultIdentity<MyUser>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>();
builder.Services.AddAuthorization(options => {

    options.AddPolicy("BusinessHoursOnly", policy =>
   policy.RequireAssertion(context => DateTime.Now.Hour >= 8
                                      && DateTime.Now.Hour <= 22
       ));
    options.AddPolicy("LoggedIn", policy =>
      {
          policy.RequireAuthenticatedUser();
      });
   
});
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("Category1", policy =>
        policy.RequireClaim("role", "admin"));

    options.AddPolicy("Category2", policy =>
      policy.RequireClaim("role", "user"));
});
//builder.Services.AddAuthorization(options =>
//{
//    options.AddPolicy("Category3", policy =>
//        policy.RequireClaim("Name", "admin"));

//    options.AddPolicy("Category4", policy =>
//      policy.RequireClaim("Name", "user"));
//});


builder.Services.AddSession(options =>
{
    options.Cookie.IsEssential = true; // This is required to make the session work in browsers that block third-party cookies
    options.IdleTimeout = TimeSpan.FromMinutes(20); // Set session timeout
    options.Cookie.Name = "YourApp.Session"; // Change cookie name as needed
    options.Cookie.HttpOnly = true; // Improve security by preventing client-side access to cookies
});
builder.Services.AddDistributedMemoryCache();
//builder.Services.AddSession(o => o.IdleTimeout = TimeSpan.FromMinutes(4));
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseSession();

app.UseAuthorization();

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=Index}/{id?}");
});
app.MapRazorPages();

app.Run();

