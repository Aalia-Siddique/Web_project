﻿namespace domain
{
	public class Class1
	{

	}
}
